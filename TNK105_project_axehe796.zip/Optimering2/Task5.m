
% Node names (for reference, not used in calculation)
nodenames = {'O', 'A', 'B', 'C', 'D', 'E', 'T'};

% Arc names (for reference, not used in calculation)
arcnames = {'OA', 'OB', 'OC', 'AB', 'AD', 'BC', 'BD', 'BE', 'CE', 'DE', 'DT', 'ET','TO'};

% Given A matrix
A = [
    %	SE1		SE2		SE3		SE4		SE5		SE6		E1A2		E1A4		E1A5		E2A1		E2A4		E2A5		E3A1		E3A3		E3A5		E4A1		E4A2		E4A5		E5A1		E5A4		E5A5		E6A2		E6A3		E6A5		A1S		A2S		A3S		A4S		A5S			
	1	,	1	,	1	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	Source
	-1	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	E1
	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	E2
	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	E3
	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	E4
	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	E5
	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	;	%	E6
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	1	,	0	,	0	,	0	,	0	;	%	A1
	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	1	,	0	,	0	,	0	;	%	A2
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	1	,	0	,	0	;	%	A3
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	0	;	%	A4
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	1	;	%	A5
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	-1	,	-1	,	-1	,	-1	;	%	Sink

];

% Cost vector (example costs for each arc)
c = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,-1];

% Balance vector b (1 for source, -1 for sink, 0 for others)
b = [0; 0; 0; 0; 0; 0; 0];

% Lower bounds (non-negative flow)
lb = zeros(size(c));

% Upper bounds (infinity for uncapacitated)
ub = [2, 5, 4, 2, 7, 2, 4, 3, 4, 2, 5, 7,inf];

% Solve using linprog
options = optimoptions('linprog', 'Algorithm', 'dual-simplex');
%options = optimoptions('linprog', 'Algorithm', 'interior-point');
[x, fval, exitflag] = linprog(c, [], [], A, b, lb, ub, options);

% Display results
if exitflag == 1
    fprintf('Optimal value: %.2f\n', fval);
    fprintf('Optimal flows:\n');
    for i = 1:length(arcnames)
        fprintf('%s: %.2f\n', arcnames{i}, x(i));
    end
else
    fprintf('No solution found.\n');
end
