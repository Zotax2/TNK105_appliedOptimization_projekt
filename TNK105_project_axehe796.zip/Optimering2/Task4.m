

% Arc names ij (for reference, not used in calculation) 
arcnames = {'11', '12', '13', '14', '22', '23', '24', '33', '34', '44', '10', '20', '30', '40'};


% Given A matrix
A = [
    %		11		12		13		14		22		23		24		33		34		44		10		20		30		40			
		1	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	0	,	0	,	0	;	%	i=1
		0	,	0	,	0	,	0	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	1	,	0	,	0	;	%	i=2
		0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	0	,	0	,	0	,	1	,	0	;	%	i=3
		0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	0	,	0	,	0	,	1	;	%	i=4
		-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	j=1
		0	,	-1	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	j=2
		0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	-1	,	0	,	0	,	0	,	0	,	0	,	0	;	%	j=3
		0	,	0	,	0	,	-1	,	0	,	0	,	-1	,	0	,	-1	,	-1	,	0	,	0	,	0	,	0	;	%	j=4
		0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	-1	,	-1	,	-1	,	-1	;	%	j=0

];

% Cost vector
c = [10	,	12	,	14	,	16	,	12	,	14	,	16	,	12	,	14	,	15	,	10	,	12	,	12	,	15	

];

% Balance vector b (1 for source, -1 for sink, 0 for others)
b = [200; 200; 200; 200; -100; -200; -150;-250;-100];

% Lower bounds (non-negative flow)
lb = zeros(size(c));

% Upper bounds (infinity for uncapacitated)
ub = inf(size(c));

% Solve using linprog
options = optimoptions('linprog', 'Algorithm', 'dual-simplex');
%options = optimoptions('linprog', 'Algorithm', 'interior-point');
[x, fval, exitflag] = linprog(c, [], [], A, b, lb, ub, options);

% Display results
if exitflag == 1
    fprintf('Optimal value: %.2f\n', fval);
    fprintf('Optimal flows:\n');
    for i = 1:length(arcnames)
        fprintf('%s: %.2f\n', arcnames{i}, x(i));
    end
else
    fprintf('No solution found.\n');
end