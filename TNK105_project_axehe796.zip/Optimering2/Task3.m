
% Arc names ij (for reference, not used in calculation) 
arcnames = {
    '11', '12', '13', '14', '15','21', '22', '23', '24', '25', '31', '32', '33', '34', '35', '41', '42', '43', '44', '45', '51', '52', '53', '54', '55'};


% Given A matrix
A = [
    %	11		12		13		14		15		21		22		23		24		25		31		32		33		34		35		41		42		43		44		45		51		52		53		54		55			
	1	,	1	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	i=1
	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	i=2
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	;	%	i=3
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	1	,	1	,	0	,	0	,	0	,	0	,	0	;	%	i=4
	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,	1	,	1	,	1	,	1	,	1	;	%	i=5
	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	;	%	j=1
	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	;	%	j=2
	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	;	%	j=3
	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	;	%	j=4
	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1	,	0	,	0	,	0	,	0	,	-1		%	j=5

];

% Cost vector (example costs for each arc)
c = [%	j=1		j=2		j=3		j=4		j=5			
	-9	,	-5	,	-6	,	0	,	0	,	%	i=1
	-7	,	-8	,	-3	,	0	,	0	,	%	i=2
	-4	,	-7	,	-5	,	0	,	0	,	%	i=3
	-3	,	-6	,	-1	,	0	,	0	,	%	i=4
	-2	,	-8	,	-4	,	0	,	0	%	i=5
];

% Balance vector b (1 for source, -1 for sink, 0 for others)
b = [1; 1; 1; 1; 1; -1; -1;-1;-1;-1];

% Lower bounds (non-negative flow)
lb = zeros(size(c));

% Upper bounds (infinity for uncapacitated)
ub = inf(size(c));

% Solve using linprog
options = optimoptions('linprog', 'Algorithm', 'dual-simplex');
%options = optimoptions('linprog', 'Algorithm', 'interior-point');
[x, fval, exitflag] = linprog(c, [], [], A, b, lb, ub, options);

% Display results
if exitflag == 1
    fprintf('Optimal value: %.2f\n', fval);
    fprintf('Optimal flows:\n');
    for i = 1:length(arcnames)
        fprintf('%s: %.2f\n', arcnames{i}, x(i));
    end
else
    fprintf('No solution found.\n');
end