
% Arc names ij (for reference, not used in calculation) 
arcnames = {'11', '12', '13', '14', '15', '21', '22', '23', '24', '25'};

% Given A matrix
A = [
    %11 12  13  14  15  21  22  23  24  25    
     1,  1,  1,  1,  1,  0,  0,  0,  0,  0; % i=1
    0,  0,  0,  0,  0,  1,  1,  1,  1,  1; % i=2
     -1, 0,  0, 0,  0,  -1,  0,  0,  0,  0; % j=1
     0,  -1, 0,  0,  0, 0,  -1,  0,  0,  0; % j=2
     0,  0,  -1,  0, 0,  0, 0,  -1,  0,  0; % j=3
     0,  0,  0,  -1,  0,  0,  0, 0, -1, 0; % j=4
     0,  0,  0,  0,  -1,  0,  0,  0,  0,  -1  % j=5
];

% Cost vector (example costs for each arc)
c = [10+2, 10+3, 10+3, 10+2, 0, 12+1, 12+2, 12+2, 12+1,0];

% Balance vector b (1 for source, -1 for sink, 0 for others)
b = [1000; 1500; -400; -700; -500; -600; -300];

% Lower bounds (non-negative flow)
lb = zeros(size(c));

% Upper bounds (infinity for uncapacitated)
ub = inf(size(c));

% Solve using linprog
options = optimoptions('linprog', 'Algorithm', 'dual-simplex');
%options = optimoptions('linprog', 'Algorithm', 'interior-point');
[x, fval, exitflag] = linprog(c, [], [], A, b, lb, ub, options);

% Display results
if exitflag == 1
    fprintf('Optimal value: %.2f\n', fval);
    fprintf('Optimal flows:\n');
    for i = 1:length(arcnames)
        fprintf('%s: %.2f\n', arcnames{i}, x(i));
    end
else
    fprintf('No solution found.\n');
end