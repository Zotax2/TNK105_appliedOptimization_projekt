% Node names (for reference, not used in calculation)
nodenames = {'O', 'A', 'B', 'C', 'D', 'E', 'T'};

% Arc names (for reference, not used in calculation)
arcnames = {'OA', 'OB', 'OC', 'AB', 'AD', 'BC', 'BD', 'BE', 'CE', 'DE', 'DT', 'ET'};

% Given A matrix
A = [
    %OA OB  OC  AB  AD  BC  BD  BE  CE  DE  DT  ET
     1,  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0; % O
    -1,  0,  0,  1,  1,  0,  0,  0,  0,  0,  0,  0; % A
     0, -1,  0, -1,  0,  1,  1,  1,  0,  0,  0,  0; % B
     0,  0, -1,  0,  0, -1,  0,  0,  1,  0,  0,  0; % C
     0,  0,  0,  0, -1,  0, -1,  0,  0,  1,  1,  0; % D
     0,  0,  0,  0,  0,  0,  0, -1, -1, -1,  0,  1; % E
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1, -1  % T
];

% Cost vector (example costs for each arc)
c = [2, 5, 4, 2, 7, 2, 4, 3, 4, 2, 5, 7];

% Balance vector b (1 for source, -1 for sink, 0 for others)
b = [1; 0; 0; 0; 0; 0; -1];

% Lower bounds (non-negative flow)
lb = zeros(size(c));

% Upper bounds (infinity for uncapacitated)
ub = inf(size(c));

% Solve using linprog
options = optimoptions('linprog', 'Algorithm', 'dual-simplex');
%options = optimoptions('linprog', 'Algorithm', 'interior-point');
[x, fval, exitflag] = linprog(c, [], [], A, b, lb, ub, options);

% Display results
if exitflag == 1
    fprintf('Optimal value: %.2f\n', fval);
    fprintf('Optimal flows:\n');
    for i = 1:length(arcnames)
        fprintf('%s: %.2f\n', arcnames{i}, x(i));
    end
else
    fprintf('No solution found.\n');
end